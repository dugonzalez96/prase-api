export interface LoginDataDto {
    username: string,
    password: string
}