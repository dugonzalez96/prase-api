export class UpdateTipoVehiculoDto {
  Nombre?: string;
  UsoID?: number;
}
