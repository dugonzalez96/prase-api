export class CreateTipoVehiculoDto {
  Nombre: string;
  UsoID: number;
}
