export class CreateDocumentosDigitalizadosDto {
    PolizaID: number;
    DocumentoID: number;
    Base64: string; // Archivo en base64
    EstadoDocumento: string;
  }
  