export class UpdateTipoPagoDto {
    Descripcion?: string;
    PorcentajeAjuste?: number;
    Divisor: number;
  }
  