export class CreateTipoPagoDto {
    Descripcion: string;
    PorcentajeAjuste: number;
    Divisor: number;
  }
  