export class UpdateTipoMonedaDto {
    Nombre?: string;
    Abreviacion?: string;
  }
  