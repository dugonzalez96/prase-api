export class CreateTipoMonedaDto {
  Nombre: string;
  Abreviacion: string;
}
