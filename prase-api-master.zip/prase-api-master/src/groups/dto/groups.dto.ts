export interface groupsI {
    id: number,
    nombre: string,
    descripcion: string
}