export class CreateUsoVehiculoDto {
    Nombre: string;
  }
  