export class UpdateUsoVehiculoDto {
    Nombre?: string;
  }
  