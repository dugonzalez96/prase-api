export class UpdateSucursalDto {
    NombreSucursal?: string;
    Direccion?: string;
    Ciudad?: string;
    Estado?: string;
    Activa?: boolean;
  }
  