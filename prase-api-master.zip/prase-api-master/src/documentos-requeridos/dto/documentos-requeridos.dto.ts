export class CreateDocumentosRequeridosDto {
    NombreDocumento: string;
    Descripcion?: string;
  }
  