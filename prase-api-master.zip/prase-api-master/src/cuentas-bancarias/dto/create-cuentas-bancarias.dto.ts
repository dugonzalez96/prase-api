export class CreateCuentasBancariasDto {
    NombreBanco: string;
    NumeroCuenta: string;
    ClabeInterbancaria?: string;
    Activa?: boolean;
  }
  