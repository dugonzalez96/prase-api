export class UpdateCuentasBancariasDto {
    NombreBanco?: string;
    NumeroCuenta?: string;
    ClabeInterbancaria?: string;
    Activa?: boolean;
  }
  