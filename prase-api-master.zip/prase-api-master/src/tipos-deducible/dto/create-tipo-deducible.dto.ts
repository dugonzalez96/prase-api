export class CreateTipoDeducibleDto {
    Nombre: string;
  }
  