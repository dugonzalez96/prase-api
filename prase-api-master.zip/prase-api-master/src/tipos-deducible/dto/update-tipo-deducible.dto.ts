export class UpdateTipoDeducibleDto {
  Nombre?: string;
}
