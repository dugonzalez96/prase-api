export class UpdateAjustePorCodigoPostalDto {
    IndiceSiniestros?: number;
    AjustePrima?: number;
    CantSiniestros?: number;
  }
  