export class CreateAjustePorCodigoPostalDto {
    CodigoPostal: string;
    IndiceSiniestros: number;
    AjustePrima: number;
    CantSiniestros?: number;
  }
  