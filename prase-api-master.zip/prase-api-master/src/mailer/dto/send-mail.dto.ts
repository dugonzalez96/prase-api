export class SendMailDto {
    to: string;
    subject: string;
    attachmentBase64: string;
    filename: string;
  }
  